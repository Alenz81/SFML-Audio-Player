//
// Created by super on 10/31/2023.
//

#include "GUIComponent.h"

